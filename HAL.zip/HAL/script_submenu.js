document.getElementById("dashboard").addEventListener("click", function (e) {
    e.preventDefault();
    let subMenu = document.getElementById("subMenudashboard");
    subMenu.classList.toggle("open-menu-dashboard");
  });



  /*document.getElementById("AAC").addEventListener("click", function (e) {
    e.preventDefault();
    let subMenu = document.getElementById("subMenuAAC");

    subMenu.classList.toggle("open-menu-dashboard");
  });




  document.getElementById("Accounts").addEventListener("click", function (e) {
    e.preventDefault();
    let subMenu = document.getElementById("subMenuAccounts");
    subMenu.classList.toggle("open-menu-dashboard");
  });

  document.getElementById("Admin").addEventListener("click", function (e) {
    e.preventDefault();
    let subMenu = document.getElementById("subMenuAdmin");

    subMenu.classList.toggle("open-menu-dashboard");
  });


  document.getElementById("Authority").addEventListener("click", function (e) {
    e.preventDefault();
    let subMenu = document.getElementById("subMenuAuthority");
    subMenu.classList.toggle("open-menu-dashboard");
  });

  document.getElementById("BEL").addEventListener("click", function (e) {
    e.preventDefault();
    let subMenu = document.getElementById("subMenuBEL");

    subMenu.classList.toggle("open-menu-dashboard");
  });*/

  document.getElementById("BILLS").addEventListener("click", function (e) {
    e.preventDefault();
    let subMenu = document.getElementById("subMenuBILLS");
    subMenu.classList.toggle("open-menu-dashboard");
  });

  /*document.getElementById("Consolidated_Report").addEventListener("click", function (e) {
    e.preventDefault();
    let subMenu = document.getElementById("subMenuConsolidated_Report");

    subMenu.classList.toggle("open-menu-dashboard");
  });

  document.getElementById("D_Section").addEventListener("click", function (e) {
    e.preventDefault();
    let subMenu = document.getElementById("subMenuD_Section");
    subMenu.classList.toggle("open-menu-dashboard");
  });

  document.getElementById("NCS").addEventListener("click", function (e) {
    e.preventDefault();
    let subMenu = document.getElementById("subMenuNCS");

    subMenu.classList.toggle("open-menu-dashboard");
  });

  document.getElementById("Records").addEventListener("click", function (e) {
    e.preventDefault();
    let subMenu = document.getElementById("subMenuRecords");
    subMenu.classList.toggle("open-menu-dashboard");
  });

  document.getElementById("Reports_ALL").addEventListener("click", function (e) {
    e.preventDefault();
    let subMenu = document.getElementById("subMenuReports_ALL");

    subMenu.classList.toggle("open-menu-dashboard");
  });

  document.getElementById("Reports_NAVY").addEventListener("click", function (e) {
    e.preventDefault();
    let subMenu = document.getElementById("subMenuReports_NAVY");

    subMenu.classList.toggle("open-menu-dashboard");
  });
  document.getElementById("Withdrawal").addEventListener("click", function (e) {
    e.preventDefault();
    let subMenu = document.getElementById("subMenuWithdrawal");

    subMenu.classList.toggle("open-menu-dashboard");
  });
  document.getElementById("enquiry").addEventListener("click", function (e) {
    e.preventDefault();
    let subMenu = document.getElementById("subMenuEnquiry");

    subMenu.classList.toggle("open-menu-dashboard");
  });*/

  function logout(){



sessionStorage.clear();
window.location.href="index.xhtml";

  }


