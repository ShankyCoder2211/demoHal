<?php
$sqlValue;
$sqlValue1;
$responseJson;
//$jsonArray=Array('country'=>'2','id'=>3);
//foreach($jsonArray as $key=>$value){echo $key; echo $value;}
//$myJson=json_encode($jsonArray);
//echo $myJson;//$raw_json = file_get_contents("php://input");
$raw=json_decode($_GET["x"],false);
$sqlValueUser=$raw->username;
$sqlValuePassword=$raw->password;
//echo $sqlValueUser;echo "----";echo $sqlValuePassword;
//$data=json_decode($raw_json,TRUE);
//echo $data->country;
/*echo  count($data['country']);
foreach($data as $key=>$value){
if($key=='country'){$sqlValue=$value;}
elseif($key=='id'){$sqlValue1=$value;}
}*/
$conn=mysqli_connect("localhost", "root", "", "haloa");
if($conn){
    $response_status;
    $rowcount;
    $sql="select * from loginids where userName='$sqlValueUser' and password='$sqlValuePassword' and isActive";
    
    $res=mysqli_query($conn,$sql);
    $rowcount=mysqli_num_rows($res);
        
    if($rowcount==1){
        $response_status=1;
    }
else if($rowcount>1){$response_status=2;}
else if($rowcount==0){$response_status=3;}

$output=Array("serverResponseStatus"=>$response_status);
$responseJson=json_encode($output);
echo $responseJson;
/*while($result=mysqli_fetch_assoc($res)){
$parent_id=$result['parent_id'];
$task=$result['task'];
$date_added=$result['date_added'];
$date_completed=$result['date_completed'];
    $output=Array("parent_id"=>$parent_id,"task"=>$task,"date_added"=>$date_added,"date_completed"=>$date_completed);
$responseJson=json_encode($output);

}*/}
?>