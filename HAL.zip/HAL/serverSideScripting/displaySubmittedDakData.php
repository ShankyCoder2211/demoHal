<?php


$raw=json_decode($_GET["x"],false);

$billId=$raw->billId;
error_reporting(0); 
$conn=mysqli_connect("localhost", "root", "", "haloa");

if ($conn){

/****aao */
    $sql_master_data="select a.id,a.rmso_no,a.Task_year,a.amount,a.created_at,a.fk_task_date,a.record_status,
    a.remarks,a.fk_AAO_date,b.userName,c.designation_abbr from rmso_master a ,loginids b,dad_designation c where a.dakid_no='$billId' and b.id=a.fk_AAO_boss
     and c.id=b.dadDesignation";

    // echo $sql_master_data;

    $res=mysqli_query($conn,$sql_master_data);
    $result=mysqli_fetch_assoc($res);
    $fk_Dak_id=$result['id'];
    $rmso_no=$result['rmso_no'];
    $Task_year=$result['Task_year'];
    $amount=$result['amount'];
    $created_at=$result['created_at'];
    $fk_task_date=$result['fk_task_date'];
    
    $record_status=$result['record_status'];
    $remarks=$result['remarks'];
    $userNameAAO=$result['userName'];
    $designation_abbrAAO=$result['designation_abbr'];
    $fk_aao_date=$result['fk_AAO_date'];
    $output_part_details=[];
    $output_pm_details=[];
    $index=0;
    $pindex=0;


  


    /**ao */
    $sql_master_data_ao="select a.fk_AO_date,b.userName,c.designation_abbr from rmso_master a ,loginids b,dad_designation c 
    where a.dakid_no='$billId' 
    and b.id=a.fk_AO_boss
     and c.id=b.dadDesignation";
     $res_ao=mysqli_query($conn,$sql_master_data_ao);
     $result_ao=mysqli_fetch_assoc($res_ao);
    $userNameAO=$result_ao['userName'];
    $designation_abbrAO=$result_ao['designation_abbr'];
    $fk_ao_date=$result_ao['fk_AO_date'];






     /**go */

     $sql_master_data_go="select a.fk_GO_date,b.userName,c.designation_abbr from rmso_master a ,loginids b,dad_designation c where a.dakid_no='$billId' 
    and b.id=a.fk_GO_boss
     and c.id=b.dadDesignation";

     $res_go=mysqli_query($conn,$sql_master_data_go);
     $result_go=mysqli_fetch_assoc($res_go);
    $userNameGO=$result_go['userName'];
    $designation_abbrGO=$result_go['designation_abbr'];
    $fk_go_date=$result_go['fk_GO_date'];


 
    
$sql_part_data="select * from rmso_part_details where fk_rmso_master='$fk_Dak_id'";
$res_part_data=mysqli_query($conn,$sql_part_data);
while($result_part_data=mysqli_fetch_assoc($res_part_data)){
    $IV_date="";
    $Sch_del_date="";
    $Actual_del_date="";
    $RV_Date="";




if($result_part_data['IV_date']!=null){list($year,$month,$day) = explode("-",$result_part_data['IV_date']);$IV_date=$day."-".$month."-".$year;}
if($result_part_data['Sch_del_date']!=null){list($year,$month,$day) = explode("-",$result_part_data['Sch_del_date']);$Sch_del_date=$day."-".$month."-".$year;}

if($result_part_data['Actual_del_date']!=null){list($year,$month,$day) = explode("-",$result_part_data['Actual_del_date']);$Actual_del_date=$day."-".$month."-".$year;}

if($result_part_data['RV_Date']!=null){list($year,$month,$day) = explode("-",$result_part_data['RV_Date']);$RV_Date=$day."-".$month."-".$year;}



    
    $output_part_details[$index]=Array(

        "Part_Number"=>$result_part_data['Part_Number'],
        "PartName"=>$result_part_data['PartName'],
        "Alt_part_no"=>$result_part_data['Alt_part_no'],
        "IV_date"=>$IV_date,
        "Sch_del_date"=>$Sch_del_date,
        "Actual_del_date"=>$Actual_del_date,
        "RV_Date"=>$RV_Date,
        "FPQ_Year"=>$result_part_data['FPQ_Year'],
        "MHR"=>$result_part_data['MHR'],
        "Lab_Hours"=>$result_part_data['Lab_Hours'],
        "FPQ_Rate_Unit_Price"=>$result_part_data['FPQ_Rate_Unit_Price'],
        "Basic_Lab_Cost"=>$result_part_data['Basic_Lab_Cost'],
        "Final_Labour_Cost"=>$result_part_data['Final_Labour_Cost'],
        "Basic_Mat_Cost"=>$result_part_data['Basic_Mat_Cost'],
        "Final_Mat_Cost"=>$result_part_data['Final_Mat_Cost'],
        "Rebate"=>$result_part_data['Rebate'],
        "Non_Bom"=>$result_part_data['Non_Bom'],
        "FNI"=>$result_part_data['FNI'],
        "BCD_Cess"=>$result_part_data['BCD_Cess'],
        "Claimed_Amt"=>$result_part_data['Claimed_Amt'],
        "Adjusted_Claimed"=>$result_part_data['Adjusted_Claimed'],
        "Gross"=>$result_part_data['Gross'],
        "Income_Tax"=>$result_part_data['Income_Tax'],
        "Service_Tax"=>$result_part_data['Service_Tax'],
        "VAT"=>$result_part_data['VAT'],
        "CGST"=>$result_part_data['CGST'],
        "SGST"=>$result_part_data['SGST'],
        "IGST"=>$result_part_data['IGST'],
        "TDS_basic_Cost"=>$result_part_data['TDS_basic_Cost'],
        "TDS_CGST"=>$result_part_data['TDS_CGST'],
        "TDS_SGST"=>$result_part_data['TDS_SGST'],
        "TDS_IGST"=>$result_part_data['TDS_IGST'],
        "LD"=>$result_part_data['LD'],
        "Interest"=>$result_part_data['Interest'],
        "Nature_Of_Work"=>$result_part_data['Nature_Of_Work'],
        "Engine"=>$result_part_data['Engine'],
        "PFACTOR"=>$result_part_data['PFACTOR'],
        "Xlist"=>$result_part_data['Xlist'],
        "Ylist"=>$result_part_data['Ylist'],
        "Profit_Warranty_On_Lab_Cost"=>$result_part_data['Profit_Warranty_On_Lab_Cost'],
        "Profit_Warranty_On_Mat_Cost"=>$result_part_data['Profit_Warranty_On_Mat_Cost'],
        "RV_No"=>$result_part_data['RV_No'],
        "Tran_Type"=>$result_part_data['Tran_Type']
        


    );
   

    $index++;




}

$sql_data_pm="select * from pm_table where fk_rmso_master='$fk_Dak_id' and record_status!='R'";

$res_pm_data=mysqli_query($conn,$sql_data_pm);
while($result_pm_data=mysqli_fetch_assoc($res_pm_data)){
    $sign;
     
    if($result_pm_data['sign']=="+"){$sign="P";}
    else if($result_pm_data['sign']=="-"){$sign="M";}


    $output_pm_details[$pindex]=Array(

        "prefix"=>$result_pm_data['prefix'],
        "codeHead"=>$result_pm_data['codeHead'],
        "sign"=>$sign,
        "R_C"=>$result_pm_data['R_C'],
        "amount"=>$result_pm_data['amount']
        

    );

    $pindex++;


}


$sql_data_pm_distinct="select distinct pm_month_year,vr_class,vr_no,pm_section_code from pm_table where fk_rmso_master='$fk_Dak_id' and record_status!='R'";

$res_pm_data_distinct=mysqli_query($conn,$sql_data_pm_distinct);
    $result_pm_data_distinct=mysqli_fetch_assoc($res_pm_data_distinct);

    


$final=Array(
    "fk_Dak_id"=>$fk_Dak_id,
    "rmso_no"=>$rmso_no,
    "Task_year"=>$Task_year,
    "amount"=>$amount,
    "created_at"=>$created_at,
    "fk_task_date"=>$fk_task_date,
    "record_status"=>$record_status,
    "remarks"=>$remarks,
    "userNameAAO"=>$userNameAAO,
    "designation_abbrAAO"=>$designation_abbrAAO,
    "fk_aao_date"=>$fk_aao_date,
    "userNameAO"=>$userNameAO,
    "designation_abbrAO"=>$designation_abbrAO,
    "fk_ao_date"=>$fk_ao_date,
    "userNameGO"=>$userNameGO,
    "designation_abbrGO"=>$designation_abbrGO,
    "fk_go_date"=>$fk_go_date,
    "output_part_details"=>$output_part_details,
    "output_pm_details"=>$output_pm_details,
    "pm_month_year"=>$result_pm_data_distinct['pm_month_year'],
    "vr_class"=>$result_pm_data_distinct['vr_class'],
    "vr_no"=>$result_pm_data_distinct['vr_no'],
    "pm_section_code"=>$result_pm_data_distinct['pm_section_code']


    

);

echo json_encode($final);

    



      
        

        





    


    



}




















?>