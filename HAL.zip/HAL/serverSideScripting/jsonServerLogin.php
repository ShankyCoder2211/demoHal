<?php
$sqlValue;
$sqlValue1;
$responseJson;
//$jsonArray=Array('country'=>'2','id'=>3);
//foreach($jsonArray as $key=>$value){echo $key; echo $value;}
//$myJson=json_encode($jsonArray);
//echo $myJson;//$raw_json = file_get_contents("php://input");
$raw=json_decode($_GET["x"],false);
$sqlValueUser=$raw->username;
$sqlValuePassword=$raw->password;
//echo $sqlValueUser;echo "----";echo $sqlValuePassword;
//$data=json_decode($raw_json,TRUE);
//echo $data->country;
/*echo  count($data['country']);
foreach($data as $key=>$value){
if($key=='country'){$sqlValue=$value;}
elseif($key=='id'){$sqlValue1=$value;}
}*/
$conn=mysqli_connect("localhost", "root", "", "haloa");
if($conn){
    $response_status;
    $rowcount;
    $office_name;
    $office_address;
    $office_telephone_no;
    $office_email_id;
    $sql="select * from loginids where userName='$sqlValueUser' and password='$sqlValuePassword' and isActive";
    
    $res=mysqli_query($conn,$sql);
    $rowcount=mysqli_num_rows($res);
        
    if($rowcount==1){
        $result=mysqli_fetch_assoc($res);
        $response_status=1;
        $fk_task_usr=$result['id'];
        $fk_office_id=$result['office_code'];
$sql_fetch_office_details="select * from hal_office_details where id='$fk_office_id'";
$res=mysqli_query($conn,$sql_fetch_office_details);
$result_office=mysqli_fetch_assoc($res);
$office_name=$result_office['office_name'];
$pm_section_code=$result_office['pm_section_code'];

    $office_address=$result_office['office_address'];
    $office_email=$result_office['office_email'];
    $office_telephone_no=$result_office['office_telephone_no'];

    $fk_dad_designation=$result['dadDesignation'];
    $sql_fetch_designation_details="select * from dad_designation where id='$fk_dad_designation'";
    $res_dad=mysqli_query($conn,$sql_fetch_designation_details);
$result_dad_designation=mysqli_fetch_assoc($res_dad);
$designation_id=$result_dad_designation['id'];
$designation_name=$result_dad_designation['designation_name'];
$designation_abbr=$result_dad_designation['designation_abbr'];






    $output=Array("serverResponseStatus"=>$response_status,"fk_task_usr"=>$fk_task_usr,"office_name"=>$office_name,"office_address"=>$office_address,"office_email"=>$office_email,"office_telephone_no"=>$office_telephone_no,
    "designation_id"=>$designation_id,"designation_name"=>$designation_name,"designation_abbr"=>$designation_abbr,"pm_section_code"=>$pm_section_code,"fk_office_id"=>$fk_office_id);
$responseJson=json_encode($output);
echo $responseJson;

    }
else if($rowcount>1){$response_status=2;
    $output=Array("serverResponseStatus"=>$response_status);
    $responseJson=json_encode($output);
echo $responseJson;
    
}
else if($rowcount==0){$response_status=3;
    $output=Array("serverResponseStatus"=>$response_status);
    $responseJson=json_encode($output);
echo $responseJson;
}


/*while($result=mysqli_fetch_assoc($res)){
$parent_id=$result['parent_id'];
$task=$result['task'];
$date_added=$result['date_added'];
$date_completed=$result['date_completed'];
    $output=Array("parent_id"=>$parent_id,"task"=>$task,"date_added"=>$date_added,"date_completed"=>$date_completed);
$responseJson=json_encode($output);

}*/}
?>