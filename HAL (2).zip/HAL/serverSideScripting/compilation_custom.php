<?php
//if($key=='IV_date'){if($value==""){$IV_date="null";}else{$IV_date=date("Y-m-d",strtotime($value));$IV_date="'".$IV_date."'";}}
$raw=json_decode($_GET["x"],false);
$fromDate=$raw->fromDate;
$toDate=$raw->toDate;
$fk_office_id=(int)$raw->fk_office_id;
$codeHead=$raw->codeHead;
$searchString="";
$output_pm=[];

if(strlen($fromDate)>0){

    $fromDate=date("Y-m-d",strtotime($fromDate));
$searchString.="date(created_at)>='$fromDate' and ";}

if(strlen($toDate)>0){
    $toDate=date("Y-m-d",strtotime($toDate));


$searchString.="date(created_at)<='$toDate' and ";}

if($fk_office_id!=0){

$searchString.="fk_rmso_master in (select id from rmso_master where fk_task_usr in (select id from loginids where office_code='$fk_office_id')) and ";

}

if(strlen($codeHead)>0 && $codeHead!="0"){
    $searchString.="codeHead='$codeHead' and ";

}

$sql="select * from pm_table where ".$searchString." record_status='V' and ncs_remarks is not null order by vr_no";



$conn=mysqli_connect("localhost", "root", "", "haloa");

if($conn){

    $responseJson;
    $res=mysqli_query($conn,$sql);
    $output_pm;
    $output_office;
    $output_codeHead;
    $index=0;

    while($result=mysqli_fetch_assoc($res)){ 
        $sign;

        if($result['sign']=="+"){$sign="P";}
        else if($result['sign']=="-"){$sign="M";}

        $output_pm[$index]=Array("prefix"=>$result['prefix'],"codeHead"=>$result['codeHead'],"sign"=>$sign,"R_C"=>$result['R_C'],
        "amount"=>$result['amount'],
        "vr_class"=>$result['vr_class'],
        "vr_no"=>$result['vr_no'],
        "pm_section_code"=>$result['pm_section_code'],
        "ncs_remarks"=>$result['ncs_remarks']

    );
        $index++;



}
$responseJson=json_encode($output_pm);
echo $responseJson;


}







    







?>