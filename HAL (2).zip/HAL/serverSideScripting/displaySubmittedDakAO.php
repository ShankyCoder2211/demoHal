<?php
$sqlValue;
$sqlValue1;
$responseJson;

$raw=json_decode($_GET["x"],false);
$fk_task_usr=$raw->fk_task_usr;


$conn=mysqli_connect("localhost", "root", "", "haloa");
if($conn){
  
    $sql="select * from rmso_master where fk_AO_boss='$fk_task_usr' and  fk_AO_date is null and record_status='S'";
//echo $sql;
$responseJson;
    $fk_authority_id;
    $dakid_no;
    $rmso_no;
    $Task_year;
    $created_at;
    $record_status;
    $remarks;
     $total_dak=0;
    $res=mysqli_query($conn,$sql);
    $rowcount=mysqli_num_rows($res);
    $index=0;
    //echo $rowcount;

    if($rowcount>0){
       

 while($result=mysqli_fetch_assoc($res)){ 
    
    
    
    $output_dak[$index]=Array("fk_authority_id"=>$result['fk_authority_id'],"dakid_no"=>$result['dakid_no'],"rmso_no"=>$result['rmso_no'],"Task_year"=>$result['Task_year'],"amount"=>$result['amount'],"created_at"=>$result['created_at'],
    "record_status"=>$result['record_status'],"remarks"=>$result['remarks']);
    $index++;

    


 }
 $responseJson=json_encode($output_dak);
 echo $responseJson;

        


    }


}
?>