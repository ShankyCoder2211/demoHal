<?php 
$raw=json_decode($_GET["x"],false);

$billId=$raw->billId;

error_reporting(0); 
$conn=mysqli_connect("localhost", "root", "", "haloa");
if ($conn){

    $sql_master_data="select * from rmso_master where dakid_no='$billId'";
    $res=mysqli_query($conn,$sql_master_data);
    $result=mysqli_fetch_assoc($res);
    $fk_Dak_id=$result['id'];
    $output_part_details=[];
    $index=0;

    $sql_part_data="select * from rmso_part_details where fk_rmso_master='$fk_Dak_id'";
    $res_part_data=mysqli_query($conn,$sql_part_data);

    while($result_part_data=mysqli_fetch_assoc($res_part_data)){
        $IV_date="";
        $Sch_del_date="";
        $Actual_del_date="";
        $RV_Date="";
    
    
    
    
   // if($result_part_data['IV_date']!=null){list($year,$month,$day) = explode("-",$result_part_data['IV_date']);$IV_date=$day."-".$month."-".$year;}
    //if($result_part_data['Sch_del_date']!=null){list($year,$month,$day) = explode("-",$result_part_data['Sch_del_date']);$Sch_del_date=$day."-".$month."-".$year;}
    
   // if($result_part_data['Actual_del_date']!=null){list($year,$month,$day) = explode("-",$result_part_data['Actual_del_date']);$Actual_del_date=$day."-".$month."-".$year;}
    
    //if($result_part_data['RV_Date']!=null){list($year,$month,$day) = explode("-",$result_part_data['RV_Date']);$RV_Date=$day."-".$month."-".$year;}
    
    
    
        
        $output_part_details[$index]=Array(
    
            "Part_Number"=>$result_part_data['Part_Number'],
            "PartName"=>$result_part_data['PartName'],
            "Alt_part_no"=>$result_part_data['Alt_part_no'],
            "IV_date"=>$result_part_data['IV_date'],
            "Sch_del_date"=>$result_part_data['Sch_del_date'],
            "Actual_del_date"=>$result_part_data['Actual_del_date'],
            "RV_Date"=>$result_part_data['RV_Date'],
            "FPQ_Year"=>$result_part_data['FPQ_Year'],
            "MHR"=>$result_part_data['MHR'],
            "Lab_Hours"=>$result_part_data['Lab_Hours'],
            "FPQ_Rate_Unit_Price"=>$result_part_data['FPQ_Rate_Unit_Price'],
            "Basic_Lab_Cost"=>$result_part_data['Basic_Lab_Cost'],
            "Final_Labour_Cost"=>$result_part_data['Final_Labour_Cost'],
            "Basic_Mat_Cost"=>$result_part_data['Basic_Mat_Cost'],
            "Final_Mat_Cost"=>$result_part_data['Final_Mat_Cost'],
            "Rebate"=>$result_part_data['Rebate'],
            "Non_Bom"=>$result_part_data['Non_Bom'],
            "FNI"=>$result_part_data['FNI'],
            "BCD_Cess"=>$result_part_data['BCD_Cess'],
            "Claimed_Amt"=>$result_part_data['Claimed_Amt'],
            "Adjusted_Claimed"=>$result_part_data['Adjusted_Claimed'],
            "Gross"=>$result_part_data['Gross'],
            "Income_Tax"=>$result_part_data['Income_Tax'],
            "Service_Tax"=>$result_part_data['Service_Tax'],
            "VAT"=>$result_part_data['VAT'],
            "CGST"=>$result_part_data['CGST'],
            "SGST"=>$result_part_data['SGST'],
            "IGST"=>$result_part_data['IGST'],
            "TDS_basic_Cost"=>$result_part_data['TDS_basic_Cost'],
            "TDS_CGST"=>$result_part_data['TDS_CGST'],
            "TDS_SGST"=>$result_part_data['TDS_SGST'],
            "TDS_IGST"=>$result_part_data['TDS_IGST'],
            "LD"=>$result_part_data['LD'],
            "Interest"=>$result_part_data['Interest'],
            "Nature_Of_Work"=>$result_part_data['Nature_Of_Work'],
            "Engine"=>$result_part_data['Engine'],
            "PFACTOR"=>$result_part_data['PFACTOR'],
            "Xlist"=>$result_part_data['Xlist'],
            "Ylist"=>$result_part_data['Ylist'],
            "Profit_Warranty_On_Lab_Cost"=>$result_part_data['Profit_Warranty_On_Lab_Cost'],
            "Profit_Warranty_On_Mat_Cost"=>$result_part_data['Profit_Warranty_On_Mat_Cost'],
            "RV_No"=>$result_part_data['RV_No'],
            "Tran_Type"=>$result_part_data['Tran_Type'],
            "isOriginalData"=>"1"
            
    
    
        );
       
    
        $index++;
    
    
    
    
    }




    echo json_encode($output_part_details);


}



?>