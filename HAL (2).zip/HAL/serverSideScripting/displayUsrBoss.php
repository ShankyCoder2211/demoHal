<?php
$sqlValue;
$sqlValue1;
$responseJson;

$raw=json_decode($_GET["x"],false);
$fk_task_usr=$raw->fk_task_usr;
$fk_office_id=$raw->fk_office_id;

//echo $fk_task_usr;echo $fk_office_id;


$conn=mysqli_connect("localhost", "root", "", "haloa");
if($conn){
  
    $sql="select a.userName,a.id ,b.designation_abbr from loginids a,dad_designation b where a.id in 
    (select fk_usr_boss  from usr_boss where fk_task_usr='$fk_task_usr' and record_status='V') and a.office_code='$fk_office_id'
    and b.id=a.dadDesignation";
//echo $sql;
$responseJson;
    $user_name;
    $id;
    $designation_abbr;
   
    $res=mysqli_query($conn,$sql);
    $rowcount=mysqli_num_rows($res);
    $index=0;
    //echo $rowcount;

    if($rowcount>0){
       

 while($result=mysqli_fetch_assoc($res)){ 
    
    
    
    $output_boss[$index]=Array("user_name"=>$result['userName'],"id"=>$result['id'],"designation_abbr"=>$result['designation_abbr']);
    $index++;

    


 }
 $responseJson=json_encode($output_boss);
 echo $responseJson;

        


    }


}
?>