<?php


$raw=json_decode($_GET["x"],false);

$pm_month=$raw->pm_month;
$conn=mysqli_connect("localhost", "root", "", "haloa");


if($conn){

    $sql_pm_fetch="select * from pm_table where pm_month_year='$pm_month' and record_status='V' and ncs_remarks is not null order by vr_no";
    $responseJson;
    $res=mysqli_query($conn,$sql_pm_fetch);
    $output_pm;
    $output_office;
    $output_codeHead;

    //$rowcount=mysqli_num_rows($res);

    $index=0;

    while($result=mysqli_fetch_assoc($res)){ 
        $sign;

        if($result['sign']=="+"){$sign="P";}
        else if($result['sign']=="-"){$sign="M";}

        $output_pm[$index]=Array("prefix"=>$result['prefix'],"codeHead"=>$result['codeHead'],"sign"=>$sign,"R_C"=>$result['R_C'],
        "amount"=>$result['amount'],
        "vr_class"=>$result['vr_class'],
        "vr_no"=>$result['vr_no'],
        "pm_section_code"=>$result['pm_section_code'],
        "ncs_remarks"=>$result['ncs_remarks']

    );
        $index++;




    }


    $sql_pm_office="select * from hal_office_details order by office_name";
    $resOffice=mysqli_query($conn,$sql_pm_office);
    //$rowcount_office=mysqli_num_rows($res);

    $index_office=0;

    while($result=mysqli_fetch_assoc($resOffice)){ 
    

        $output_office[$index_office]=Array("id"=>$result['id'],"office_name"=>$result['office_name']
    );
        $index_office++;




    }


    $sql_pm_codehead="select distinct codeHead from pm_table order by codeHead";
    $resOffice=mysqli_query($conn,$sql_pm_codehead);
    //$rowcount_office=mysqli_num_rows($res);

    $index_pm_codehead=0;

    while($result=mysqli_fetch_assoc($resOffice)){ 
    

        $output_codeHead[$index_pm_codehead]=Array("codeHead"=>$result['codeHead']
    );
        $index_pm_codehead++;




    }


$output_compilation_data=Array("output_pm"=>$output_pm,"output_office"=>$output_office,"output_codeHead"=>$output_codeHead);

    $responseJson=json_encode($output_compilation_data);
    echo $responseJson;


}


?>