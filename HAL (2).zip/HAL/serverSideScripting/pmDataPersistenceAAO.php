<?php 
$raw=json_decode($_GET["x"],false);
error_reporting(0); 

$billId=$raw->billId;
$fk_task_usr=$raw->fk_task_usr;
$fk_usr_boss=$raw->fk_usr_boss;
$AAO_narration=$raw->AAO_narration;
try{
    $conn=mysqli_connect("localhost", "root", "", "haloa");
if (!$conn) { throw new Exception(); exit(); }

else{
    if($conn){

        $sql="select * from rmso_master where dakid_no='$billId' and record_status='S' and fk_AAO_boss='$fk_task_usr' and fk_AAO_date is  null";
        $res=mysqli_query($conn,$sql);
        $rowcount=mysqli_num_rows($res);

        if($rowcount==1){

            $result=mysqli_fetch_assoc($res);

        $fk_rmso_master=$result['id'];
        $conn->begin_transaction();
        $conn -> autocommit(FALSE);
        try{
        $fk_rmso_master=$result['id'];
            $sql_update_rmso_master="update rmso_master set fk_AAO_date=now(),fk_AO_boss='$fk_usr_boss',record_status='S',remarks='Pending at AO',fk_AAO_remarks='$AAO_narration' where dakid_no='$billId' and id='$fk_rmso_master'" ;

            if(mysqli_query($conn,$sql_update_rmso_master)){

                $sql_update_pm_master="update pm_table set fk_aao_boss='$fk_task_usr',fk_aao_date=now() where fk_rmso_master='$fk_rmso_master' and record_status='P'";
                if(mysqli_query($conn,$sql_update_pm_master)){

                    $mesage="Submitted the Bill Successfully !!!!";
        $output_response=Array("serverResponseStatus"=>1,"message"=>$mesage);
        $responseJson=json_encode($output_response);
        $conn->commit();
    
        echo $responseJson;
                }

                else{
                    $mesage="Unable to Update PM";
                    $output_response=Array("serverResponseStatus"=>0,"message"=>$mesage);
                    $responseJson=json_encode($output_response);
                    $conn->rollback();
                    echo $responseJson;
                    exit();

                }
                

            }
            else{
                $mesage="Unable to Update Dakid";
                    $output_response=Array("serverResponseStatus"=>0,"message"=>$mesage);
                    $responseJson=json_encode($output_response);
                    $conn->rollback();
                    echo $responseJson;
                    exit();
            }


        }catch(Exception $e) {
            $mesage="Exception Occured While Submitting PM Data!!!Please Contact System Administrator!!";
            $output_response=Array("serverResponseStatus"=>0,"message"=>$mesage);
            $responseJson=json_encode($output_response);
            $conn->rollback();
            echo $responseJson;
            exit();
            
        }










        }

        else{

            $mesage="No Such Dakid Found!!";
            $output_response=Array("serverResponseStatus"=>0,"message"=>$mesage);
            $responseJson=json_encode($output_response);
            $conn->rollback();
            echo $responseJson;
            exit();
        
        }








    }




}


}

catch(Exception $e){

    $mesage="database not found";
        $output_response=Array("serverResponseStatus"=>0,"message"=>$mesage);
        $responseJson=json_encode($output_response);
    
        echo $responseJson;
    
    exit();
    
    
        
      }


?>


