<?php 

$raw=json_decode($_GET["x"],false);
error_reporting(0); 

$billId=$raw->billId;
$fk_task_usr=$raw->fk_task_usr;
$AO_narration=$raw->AO_narration;
$pm_section_code=$raw->pm_section_code;

try{
    $conn=mysqli_connect("localhost", "root", "", "haloa");
    if (!$conn) { throw new Exception(); exit(); }


    else{

        if($conn){
            $sql="select * from rmso_master where dakid_no='$billId' and record_status='S' and fk_AO_boss='$fk_task_usr' and fk_AO_date is  null";
            $res=mysqli_query($conn,$sql);
            $rowcount=mysqli_num_rows($res);

            if($rowcount==1){

                $result=mysqli_fetch_assoc($res);
                $fk_rmso_master=$result['id'];
            $conn->begin_transaction();
            $conn -> autocommit(FALSE);

            try{
                $fk_rmso_master=$result['id'];

                $sql_update_rmso_master="update rmso_master set fk_AO_date=now(),disposal_date=now(),record_status='D',remarks='Bill Completed',fk_AO_remarks='$AO_narration' where dakid_no='$billId' and id='$fk_rmso_master'" ;

                if(mysqli_query($conn,$sql_update_rmso_master)){


                    $sql_select_dv_no="select * from section_dv_block where pm_section_code='$pm_section_code' and nature like '%RMSO%' and fk_office_id in (select office_code from loginids where id='$fk_task_usr' and isActive) and current_record='V'";
                    $res=mysqli_query($conn,$sql_select_dv_no);
                    $rowcount=mysqli_num_rows($res);

                    if($rowcount==1){

                        $result=mysqli_fetch_assoc($res);

                        $dv_block_end=$result['dv_block_end'];

                        $new_voucher_no=$dv_block_end+1;
                       

                        $pm_month=$result['pm_month'];

                $sql_update_pm_master="update pm_table set fk_ao_boss='$fk_task_usr',fk_ao_date=now(),vr_no='$new_voucher_no',pm_month_year='$pm_month',ncs_remarks='0-Not yet posted' ,record_status='V' where fk_rmso_master='$fk_rmso_master' and record_status='P'";
               

                if(mysqli_query($conn,$sql_update_pm_master)){
                    $sql_update_dv_block="update section_dv_block set dv_block_end='$new_voucher_no' where  pm_section_code='$pm_section_code' and nature like '%RMSO%' and fk_office_id in (select office_code from loginids where id='$fk_task_usr' and isActive) and current_record='V'";
                    if(mysqli_query($conn,$sql_update_dv_block))
                                { $mesage="Bill has been approved  !!!!";
                                    $output_response=Array("serverResponseStatus"=>1,"message"=>$mesage);
                                    $responseJson=json_encode($output_response);
                                    $conn->commit();
                                
                                    echo $responseJson;}
                    
                        else{
                            $mesage="Cannot update section DV block Table!!!";
                            $output_response=Array("serverResponseStatus"=>0,"message"=>$mesage);
                            $responseJson=json_encode($output_response);
                            $conn->rollback();
                            echo $responseJson;
                            exit();



                    }

                }

                else{
                    $mesage="Cannot update PM Table!!!";
                    $output_response=Array("serverResponseStatus"=>0,"message"=>$mesage);
                    $responseJson=json_encode($output_response);
                    $conn->rollback();
                    echo $responseJson;
                    exit();

                }




                    }


                    else{
                        $mesage="No Section DV Block Found!!!";
                            $output_response=Array("serverResponseStatus"=>0,"message"=>$mesage);
                            $responseJson=json_encode($output_response);
                            $conn->rollback();
                            echo $responseJson;
                            exit();
                    }
    





                }

                else{
                    $mesage="Unable to Update Dakid";
                        $output_response=Array("serverResponseStatus"=>0,"message"=>$mesage);
                        $responseJson=json_encode($output_response);
                        $conn->rollback();
                        echo $responseJson;
                        exit();
                }




            }

            catch(Exception $e) {
                $mesage="Exception Occured While Approving PM Data!!!Please Contact System Administrator!!";
                $output_response=Array("serverResponseStatus"=>0,"message"=>$mesage);
                $responseJson=json_encode($output_response);
                $conn->rollback();
                echo $responseJson;
                exit();
                
            }





            }


            else{

                $mesage="No Such Dakid Found!!";
                $output_response=Array("serverResponseStatus"=>0,"message"=>$mesage);
                $responseJson=json_encode($output_response);
                $conn->rollback();
                echo $responseJson;
                exit();
            
            }







        }

    }




}
catch(Exception $e){

    $mesage="database not found";
        $output_response=Array("serverResponseStatus"=>0,"message"=>$mesage);
        $responseJson=json_encode($output_response);
    
        echo $responseJson;
    
    exit();
    
    
        
      }

?>