<?php


$raw=json_decode($_GET["x"],false);


error_reporting(0); 
$billId=$raw->billId;
$codeHead=$raw->codeHead;
$fk_task_usr=$raw->fk_task_usr;
$fk_usr_boss=$raw->fk_usr_boss;
$pm_data_entries_local_Storage=$raw->pm_data_entries_local_Storage;
$PartDetails=$raw->PartDetails;
$class_num=$raw->class_num;
$pm_month=$raw->pm_month;
$pm_section_code=$raw->pm_section_code;

try{
$conn=mysqli_connect("localhost", "root", "", "haloa");
if (!$conn) { throw new Exception(); exit(); }


  else{


if($conn){

    $sql="select * from rmso_master where dakid_no='$billId' and record_status='P'";
    $res=mysqli_query($conn,$sql);
    $rowcount=mysqli_num_rows($res);
        
    if($rowcount==1){

        $result=mysqli_fetch_assoc($res);

        $fk_rmso_master=$result['id'];


$conn->begin_transaction();

$conn -> autocommit(FALSE);
try{
$sql_update_rmso_master="update rmso_master set fk_task_date=now(),fk_AAO_boss='$fk_usr_boss',record_status='S',remarks='Pending at AAO' where dakid_no='$billId'" ;

if(mysqli_query($conn,$sql_update_rmso_master)){
    $all_part_added=false;
    $no_part_missed=true;
    $all_pm_added=false;
    $no_pm_missed=true;
 $Part_Number;
 $PartName;
 $Alt_part_no;
 $IV_date;
 $Sch_del_date;
 $Actual_del_date;
 $RV_Date;
 $FPQ_Year;
 $MHR;
 $Lab_Hours;
 $FPQ_Rate_Unit_Price;
 $Basic_Lab_Cost;
 $Final_Labour_Cost;
 $Basic_Mat_Cost;
 $Final_Mat_Cost;
 $Rebate;
 $Non_Bom;
 $FNI;
 $BCD_Cess;
 $Claimed_Amt;
 $Adjusted_Claimed;
 $Gross;
 $Income_Tax;
 $Service_Tax;
 $VAT;
 $CGST;
 $SGST;
 $IGST;
 $TDS_basic_Cost;
 $TDS_CGST;
 $TDS_SGST;
 $TDS_IGST;
 $LD;
 $Interest;
 $Nature_Of_Work;
 $Engine;
 $PFACTOR;
 $Xlist;
 $Ylist;
 $Profit_Warranty_On_Lab_Cost;
 $Profit_Warranty_On_Mat_Cost;
 $RV_No;
 $Tran_Type;
 $isOriginalData;


$element_count=count($PartDetails);
//echo $element_count;
/*persisting part details */



foreach ($PartDetails as $key => $jsons) {
   foreach($jsons as $key => $value) {
    if($key=='Part_Number'){ $Part_Number=$value;}
    else if($key=='PartName'){$PartName=$value;}
    else if($key=='Alt_part_no'){$Alt_part_no=$value;}
    else if($key=='IV_date'){if($value==""){$IV_date="null";}else{$IV_date=date("Y-m-d",strtotime($value));$IV_date="'".$IV_date."'";}}
    else if($key=='Sch_del_date'){if($value==''){$Sch_del_date="null";}else {$Sch_del_date=date("Y-m-d",strtotime($value));$Sch_del_date="'".$Sch_del_date."'";}}
    else if($key=='Actual_del_date'){if($value==''){$Actual_del_date="null";}else {$Actual_del_date=date("Y-m-d",strtotime($value));$Actual_del_date="'".$Actual_del_date."'";}}
    else if($key=='RV_Date'){if($value==''){$RV_Date="null";}else {$RV_Date=date("Y-m-d",strtotime($value));$RV_Date="'".$RV_Date."'";}}
    else if($key=='FPQ_Year'){$FPQ_Year=$value;}
    else if($key=='MHR'){if($value==''){$MHR=0;}else {$MHR=$value;}}
    else if($key=='Lab_Hours'){if($value==''){$Lab_Hours=0;}else {$Lab_Hours=$value;}}
    else if($key=='FPQ_Rate_Unit_Price'){if($value==''){$FPQ_Rate_Unit_Price=0;}else {$FPQ_Rate_Unit_Price=$value;}}
    else if($key=='Basic_Lab_Cost'){if($value==''){$Basic_Lab_Cost=0;}else {$Basic_Lab_Cost=$value;}}
    else if($key=='Final_Labour_Cost'){if($value==''){$Final_Labour_Cost=0;}else {$Final_Labour_Cost=$value;}}
    else if($key=='Basic_Mat_Cost'){if($value==''){$Basic_Mat_Cost=0;}else {$Basic_Mat_Cost=$value;}}
    else if($key=='Final_Mat_Cost'){if($value==''){$Final_Mat_Cost=0;}else {$Final_Mat_Cost=$value;}}
    else if($key=='Rebate'){if($value==''){$Rebate=0;}else {$Rebate=$value;}}
    else if($key=='Non_Bom'){if($value==''){$Non_Bom=0;}else {$Non_Bom=$value;}}
    else if($key=='FNI'){if($value==''){$FNI=0;}else {$FNI=$value;}}
    else if($key=='BCD_Cess'){if($value==''){$BCD_Cess=0;}else {$BCD_Cess=$value;}}
    else if($key=='Claimed_Amt'){if($value==''){$Claimed_Amt=0;}else {$Claimed_Amt=$value;}}
    else if($key=='Adjusted_Claimed'){if($value==''){$Adjusted_Claimed=0;}else {$Adjusted_Claimed=$value;}}
    else if($key=='Gross'){if($value==''){$Gross=0;}else {$Gross=$value;}}
    else if($key=='Income_Tax'){if($value==''){$Income_Tax=0;}else {$Income_Tax=$value;}}
    else if($key=='Service_Tax'){if($value==''){$Service_Tax=0;}else {$Service_Tax=$value;}}
    else if($key=='VAT'){if($value==''){$VAT=0;}else {$VAT=$value;}}
    else if($key=='CGST'){if($value==''){$CGST=0;}else {$CGST=$value;}}
    else if($key=='SGST'){if($value==''){$SGST=0;}else {$SGST=$value;}}
    else if($key=='IGST'){if($value==''){$IGST=0;}else {$IGST=$value;}}
    else if($key=='TDS_basic_Cost'){if($value==''){$TDS_basic_Cost=0;}else {$TDS_basic_Cost=$value;}}
    else if($key=='TDS_CGST'){if($value==''){$TDS_CGST=0;}else {$TDS_CGST=$value;}}
    else if($key=='TDS_SGST'){if($value==''){$TDS_SGST=0;}else {$TDS_SGST=$value;}}
    else if($key=='TDS_IGST'){if($value==''){$TDS_IGST=0;}else {$TDS_IGST=$value;}}
    else if($key=='LD'){if($value==''){$LD=0;}else {$LD=$value;}}
    else if($key=='Interest'){if($value==''){$Interest=0;}else {$Interest=$value;}}
    else if($key=='Nature_Of_Work'){$Nature_Of_Work=$value;}
    else if($key=='Engine'){$Engine=$value;}
    else if($key=='PFACTOR'){$PFACTOR=$value;}
    else if($key=='Xlist'){$Xlist=$value;}
    else if($key=='Ylist'){$Ylist=$value;}
    else if($key=='Profit_Warranty_On_Lab_Cost'){$Profit_Warranty_On_Lab_Cost=$value;}
    else if($key=='Profit_Warranty_On_Mat_Cost'){$Profit_Warranty_On_Mat_Cost=$value;}
    else if($key=='RV_No'){$RV_No=$value;}
    else if($key=='Tran_Type'){$Tran_Type=$value;}
    else if($key=='isOriginalData'){$isOriginalData=$value;}

   }



  



//echo $sql_insert_part_details;

$sql="select * from rmso_part_details where Part_number='$Part_Number'";
$res=mysqli_query($conn,$sql);
$rowcount=mysqli_num_rows($res);

if($rowcount>=1 && $isOriginalData=="1") {
    $sql_insert_part_details="UPDATE rmso_part_details
    SET 
    PartName='$PartName',Alt_part_no='$Alt_part_no',IV_date=$IV_date,
    Sch_del_date=$Sch_del_date,Actual_del_date=$Actual_del_date,
    RV_Date=$RV_Date,FPQ_Year='$FPQ_Year',MHR='$MHR',
    Lab_Hours='$Lab_Hours',FPQ_Rate_Unit_Price='$FPQ_Rate_Unit_Price',Basic_Lab_Cost='$Basic_Lab_Cost',
    Final_Labour_Cost='$Final_Labour_Cost',Basic_Mat_Cost='$Basic_Mat_Cost',Final_Mat_Cost='$Final_Mat_Cost',
    Rebate='$Rebate',Non_Bom='$Non_Bom',FNI='$FNI',BCD_Cess='$BCD_Cess',Claimed_Amt='$Claimed_Amt',
    Adjusted_Claimed='$Adjusted_Claimed',Gross='$Gross',Income_Tax='$Income_Tax',Service_Tax='$Service_Tax',
    VAT='$VAT',CGST='$CGST',SGST='$SGST',IGST='$IGST',TDS_basic_Cost='$TDS_basic_Cost',
    TDS_CGST='$TDS_CGST',TDS_SGST='$TDS_SGST',TDS_IGST='$TDS_IGST',LD='$LD',Interest='$Interest',
    Nature_Of_Work='$Nature_Of_Work',Engine='$Engine',PFACTOR='$PFACTOR',Xlist='$Xlist',Ylist='$Ylist',
    Profit_Warranty_On_Lab_Cost='$Profit_Warranty_On_Lab_Cost',Profit_Warranty_On_Mat_Cost='$Profit_Warranty_On_Mat_Cost',RV_No='$RV_No',
    Tran_Type='$Tran_Type' WHERE fk_rmso_master='$fk_rmso_master' and Part_number='$Part_Number'";
    
}
else if($isOriginalData=="0") {
    $sql_insert_part_details="INSERT INTO rmso_part_details ( fk_rmso_master, Part_Number, PartName, Alt_part_no, IV_date, 
    Sch_del_date, Actual_del_date, RV_Date, FPQ_Year, MHR, Lab_Hours, FPQ_Rate_Unit_Price, Basic_Lab_Cost, 
    Final_Labour_Cost, Basic_Mat_Cost, Final_Mat_Cost, Rebate, Non_Bom, FNI, BCD_Cess, Claimed_Amt,
     Adjusted_Claimed, Gross, Income_Tax, Service_Tax, VAT, CGST, SGST, IGST, TDS_basic_Cost, 
     TDS_CGST, TDS_SGST, TDS_IGST, LD, Interest, Nature_Of_Work, Engine, PFACTOR,
     Xlist, Ylist, Profit_Warranty_On_Lab_Cost, Profit_Warranty_On_Mat_Cost, RV_No, Tran_Type) values
 ($fk_rmso_master,'$Part_Number','$PartName','$Alt_part_no',$IV_date,$Sch_del_date,$Actual_del_date,$RV_Date,'$FPQ_Year',$MHR,
     $Lab_Hours, $FPQ_Rate_Unit_Price, $Basic_Lab_Cost, $Final_Labour_Cost, $Basic_Mat_Cost, $Final_Mat_Cost, $Rebate, $Non_Bom, $FNI, $BCD_Cess, $Claimed_Amt,$Adjusted_Claimed, $Gross, $Income_Tax,$Service_Tax,$VAT,$CGST,$SGST,$IGST,$TDS_basic_Cost,$TDS_CGST,$TDS_SGST,$TDS_IGST,$LD,$Interest,'$Nature_Of_Work'
 ,'$Engine','$PFACTOR','$Xlist','$Ylist','$Profit_Warranty_On_Lab_Cost','$Profit_Warranty_On_Mat_Cost','$RV_No','$Tran_Type')";


}

else{
    $mesage="Problem with Part Details";
        $output_response=Array("serverResponseStatus"=>0,"message"=>$mesage);
        $responseJson=json_encode($output_response);
        $conn->rollback();
    
        echo $responseJson;
        exit();



}

if(mysqli_query($conn,$sql_insert_part_details)){$all_part_added=true;}
else{$no_part_missed=false;}










}




$sql="select * from pm_table where fk_rmso_master='$fk_rmso_master' and record_status!='R'";
$res=mysqli_query($conn,$sql);
$rowcount=mysqli_num_rows($res);
if($rowcount>=1){

    $mesage="PM already exists!!!!";
        $output_response=Array("serverResponseStatus"=>0,"message"=>$mesage);
        $responseJson=json_encode($output_response);
        $conn->rollback();
    
        echo $responseJson;
        exit();

}

else{
foreach ($pm_data_entries_local_Storage as $key => $jsons) {
    $fk_rmso_master;
    $prefix;
    $codehead;
    $sign;
    $side;
    $amount;
    //fk_task_usr
    //$fk_task_date;
    $record_status="P";
   foreach($jsons as $key => $value) {
    if($key=="prefix"){$prefix=$value;}
    else if($key=="codehead"){$codehead=$value;}
    else if($key=="amount"){$amount=$value;}
    else if($key=="sign" && $value=='P'){$sign="+";}
    else if($key=="sign" && $value=='M'){$sign="-";}
    else if($key=="side"){$side=$value;}
}


$sql_insert_pm="INSERT INTO pm_table ( fk_rmso_master, prefix, codeHead, sign, R_C, amount,pm_month_year,vr_class,pm_section_code,
 fk_task_usr, fk_task_date, record_status,created_at) 
VALUES ($fk_rmso_master, '$prefix', '$codehead', '$sign', '$side',$amount,'$pm_month',$class_num,'$pm_section_code',$fk_task_usr,now(),'$record_status',now())";






   if(mysqli_query($conn,$sql_insert_pm)){$all_pm_added=true;}
else{$no_pm_missed=false;}
}
}





if($all_part_added && $no_part_missed && $all_pm_added && $no_pm_missed){

    


    $mesage="Submitted the Bill Successfully !!!!";
        $output_response=Array("serverResponseStatus"=>1,"message"=>$mesage);
        $responseJson=json_encode($output_response);
        $conn->commit();
    
        echo $responseJson;
        
}

   


    


  



/*----------------*/


 

  








    

}

else{
    $mesage="Unable to Update Dakid";
        $output_response=Array("serverResponseStatus"=>0,"message"=>$mesage);
        $responseJson=json_encode($output_response);
        $conn->rollback();
        echo $responseJson;
        exit();
}
}/*try*/

catch(Exception $e) {
    $conn->rollback();
    echo "Exception Occured While Submitting PM Data!!!Please Contact System Administrator!!";
}



    }


    else{

        $mesage="No Pending Dakid Found";
        $output_response=Array("serverResponseStatus"=>0,"message"=>$mesage);
        $responseJson=json_encode($output_response);
        $conn->rollback();
        echo $responseJson;
        exit();
    
    }



}


  }
}

  catch(Exception $e){

$mesage="database not found";
    $output_response=Array("serverResponseStatus"=>0,"message"=>$mesage);
    $responseJson=json_encode($output_response);

    echo $responseJson;

exit();


    
  }

















?>