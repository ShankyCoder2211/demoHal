<!DOCTYPE composition
  PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">


<head>



  <script src="jquery.min.js"></script>


  <script type="text/javascript">

function check_Login(){

var username=document.getElementById("username").value;
var password =document.getElementById("password").value;

if(username ==""){alert("please enter username"); return false;}
if((password=="") ||  (7>=password.length)){alert("please enter password/Enter Complete Password");return false;}
var jsonArray={username:username,password:password};
//alert(jsonArray);
var jsonClientData=JSON.stringify(jsonArray);
var request=new XMLHttpRequest();
if(window.XMLHttpResquest){
     request=new XMLHttpRequest();}
    else if (window.ActiveXObject){ request=new ActiveXObject("Microsoft.XMLHTTP");}
    var method='GET';

var url="jsonServerLogin.php";
requestExactData(request,url,jsonClientData,method);


}

function requestExactData(request,url,data,method){
        if(request){
          if(method=='GET')

{request.open('GET',url+'?'+'x='+data,true);}
else {  request.open('POST',url,true);}
request.setRequestHeader('content-type','application/json');

request.onreadystatechange=function(){if(request.readyState==4){if (request.status==200){
    {
      var jsonString=request.responseText;
      console.log(jsonString); 
      var response=eval('('+jsonString+')'); 
    

    }}
    }};


if (method=='GET') request.send();

else {
  var data ="x="+data;
  request.send(data);}


        }}




  </script>
    <style>
    body {
      box-sizing: border-box;
      margin: 0;
      padding: 0px 0px;
      background-color: rgba(39, 37, 37, 0.262);
      font-family: "lato", sans-serif;
      background-image: url("hal.jpg");
      background-repeat: no-repeat;
      background-size: cover;
      backdrop-filter: blur(5px);
      height: 100%;
      cursor: url("heli.png"), auto;



    }

    .signupFrm {
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 200px 0px;

    }

    .table {

      display: flex;
      justify-content: center;
      align-items: center;
      margin: 0;
      padding: 0px 0px;

    }

    .form {
      background-color: white;
      width: 500px;
      
      border-radius: 6px;
      padding: 20px 40px;
      box-shadow: 0 10px 25px rgba(16, 31, 45, 0.2);
      border-style: solid;
      border-color: black;
      border-block-width: thick;
      background-image: url("tri.png");
      background-repeat: no-repeat;
      background-size: cover;
      background-position: 40px 340px;
      backdrop-filter: blur(5px);



    }

    .title {
      font-size: 50px;
      margin-bottom: 50px;
      justify-content: center;
    }

    .inputContainer {
      position: relative;
      text-align: center;
      justify-content: center;
      height: 45px;
      width: 45%;
      margin-bottom: 17px;
      margin-top: 17px;
      margin-right: 20px;
      margin-left: 120px;
      transition: width 0.10s ease-in-out;
    }

    .input {
      position: absolute;
      top: 0px;
      left: 0px;
      height: 100%;
      width: 100%;
      border: 1px solid #DADCE0;
      border-radius: 7px;
      font-size: 16px;
      padding: 0 20px;
      outline: none;
      background: none;
      z-index: 1;
    }

    /* Hide the placeholder texts (a) */

    ::placeholder {
      color:transparent;
    }
    

    .label {
      position: absolute;
      top: 15px;
      left: 15px;
      padding: 0 4px;
      background-color: white;
      color: #DADCE0;
      font-size: 16px;
      transition: 0.5s;
      z-index: 0;
    }

    .submitBtn {
      display: block;
      margin-left: 10px;
      padding: 15px 30px;
      border: none;
      background-color: purple;
      color: white;
      border-radius: 6px;
      cursor: pointer;
      font-size: 16px;
      margin-top: 10px;
      cursor: pointer;


    }

    .submitBtn:hover {
      background-color: green;
      transform: translateY(-2px);
    }

    .input:focus+.label {
      top: -7px;
      left: 3px;
      z-index: 10;
      font-size: 14px;
      font-weight: 600;
      color: purple;
      width: 100%;
    }

    .input:focus {
      border: 2px solid purple;
      width: 100%;
    }

    .input:not(:placeholder-shown)+.label {
      top: -7px;
      left: 3px;
      z-index: 10;
      font-size: 14px;
      font-weight: 600;
    }

    th,
    td {
      padding-top: 0px;
      padding-bottom: 0px;
      padding-left: 0px;
      padding-right: 0px;
    }

    input[type=text] {
      width: 180px;
      -webkit-transition: width 0.4s ease-in-out;
      transition: width 0.4s ease-in-out;
    }

    /* When the input field gets focus, change its width to 100% */
    input[type=text]:focus {
      width: 100%;
    }

    input[type=password] {
      width: 180px;
      -webkit-transition: width 0.4s ease-in-out;
      transition: width 0.4s ease-in-out;
    }

    /* When the input field gets focus, change its width to 100% */
    input[type=password]:focus {
      width: 100%;
    }

    /*.cockpit {
      position: absolute;
      overflow: hidden;
      z-index: 1;
      width: 70px;
      height: 70px;
      border-radius: 100px 40px 50px 50px;
      background-color: #44d2fd;
    }

    .cockpit::before {
      content: "";
      position: absolute;
      z-index: 1;
      top: -10px;
      left: -25px;
      width: 70px;
      height: 70px;
      border-radius: 40px;
      background-color: #302e37;
    }

    .cockpit::after {
      content: "";
      position: absolute;
      z-index: 1;
      top: -60px;
      left: -60px;
      width: 70px;
      height: 70px;
      border-radius: 40px;
      background-color: rgba(255, 255, 255, 0.05);
    }

    .tail {
      position: absolute;
      top: 25px;
      left: 25px;
      transform-origin: left center;
      border-top: 5px solid transparent;
      border-bottom: 8px solid transparent;
      border-left: 100px solid #2fadd2;
      border-bottom-right-radius: 10px;
      height: 10px;
    }

    .main {
      position: absolute;
      left: 30px;
      top: -10px;
      width: 10px;
      height: 20px;
      background: #302e37;
    }

    .rotor {
      width: 300px;
      height: 700px;
      border-radius: 200px;
      position: absolute;
      top: -360px;
      left: -130px;
      z-index: 2;
      overflow: hidden;
      background-color: #a299ab;
      opacity: 0.12;
      transform: scaleY(0.020);
    }

    .rotator div {
      position: absolute;
      top: 50%;
      left: 50%;
      margin-left: -350px;
      margin-top: -30px;
      width: 70px;
      height: 80px;
      background-color: #fff;
    }

    .rotator div:nth-child(1) {
      transform: rotate(0deg);
    }

    .rotor div:nth-child(2) {
      transform: rotate(90deg);
    }

    @keyframes bounce {

      0%,
      100% {
        transform: translate(0px, -30px) rotate(-15deg);
      }

      50% {
        transform: translate(0px, 30px) rotate(-10deg);
      }
    }

    @keyframes rotate {
      0% {
        transform: rotate(0deg);
      }

      100% {
        transform: rotate(360deg);
      }
    }

    .helicopter {
      animation: bounce 5s infinite;
      /* adding bounce keyframes with duration 5s and infinite loop 
    
    }
    .rotator {
      position: absolute;
      width: 700px;
      height: 700px;
      border-radius: 35px;
      animation: rotate 0.6s linear infinite;
    
    }*/
  </style>
</head>

<body class="body">




  <table class="table" border="0" style="width: 1500px;" cellspacing="0" cellpadding="0">

    <div class="signupFrm">
      <form  class="form" id="loginForm" onsubmit="return false">
        <tr>
          <th colspan="3">
            <div>
              <center><img alt="W3C Logo" src="dad.jpg" style="height: 200px; width: 200px;"></img></center>
            </div>
          </th>
        </tr>

       <!-- <tr>
          <th></th>
          <th></th>
          
          <th><img alt="W3C Logo" src="helani.gif" style="height: 90px; width: 90px;"></img></th>
          
          <th width="100%">
            <main class="helicopter">
              <div class="cockpit"></div>
              <div class="tail"></div>
              <div class="main"></div>
              <div class="rotor">
                <div class="rotator">
                  <div></div>
                  <div></div>
                </div>
              </div>
            </main>
          </th>
        </tr>-->


        <tr>
          <th colspan="3" width="100%">

            <div>
              <center>

                <h1><b>
                    <font face="Verdana">
                      <marquee>Welcome to HAL</marquee>
                      <marquee direction="right" behaviour="alternate"></marquee>
                      

                    </font>
                  </b></h1>
              </center>
            </div>

          </th>
          <th><img alt="W3C Logo" src="helani.gif" style="height: 120px; width: 120px;"></img></th>
        </tr>
        <tr style="margin: 0px;padding: 0px;border-spacing: 0px;">
          <td width="33%" style="margin: 0px;padding: 0px;margin-top: 200px;">

            <div>
              <center><img alt="W3C Logo" src="azaadi75.jpg" style="height: 100px; width: 200px;"></img></center>
            </div>

          </td>
          <td width="33%" style="margin: 0;padding: 0; border-spacing: 0;border-collapse: collapse;"> <strong>

              <div id ="message_display">
                <font size="4" color="red">
                  <center>Good Morning!!!!</center>
                </font>
              </div>

            </strong></td>

          <td width="33%">

            <div>
              <center><img alt="W3C Logo" src="version.png" style="height: 100px; width: 200px;"></img></center>
            </div>

          </td>
        </tr>


        <tr>
          <th colspan="3" width="100%">
            <div class="inputContainer">
              <label for="" class="label">UserName</label>
              <input type="text"  name="username" id="username"   class="input" placeholder="username"></input>

            </div>
          </th>
        </tr>
        <tr>
          <th colspan="3" width="100%">
            <div class="inputContainer">
              <label for="" class="label">Password</label>
              <input type="password" id="password"  name="password" class="input" placeholder="password" />

            </div>
          </th>
        </tr>
        <tr>
          <th colspan="3" width="100%">
            <center><input type="submit" class="submitBtn" value="Submit"  onclick="check_Login()"/></center>
          </th>
        </tr>

        <tr>

          <td style="margin-top: 1000px;">
            <font color="purple"><br /><br /><br /><b> रक्षा लेखा महानियंत्रक </b><br />
              <b>Controller General of Defence Accounts</b><br />

              <b>PCDA Bengaluru</b>
            </font>
          </td>
          <td><br /><br /><br /><br></br><br></br>
            <center><a href="">
                <font color="purple"><b>Sign Up</b></font>
              </a></center>
          </td>
          <td><br /><br /><br /><br></br><br></br>
            <center><a href="">
                <font color="purple"><b>Help</b></font>
              </a></center>
          </td>
        </tr>

      </form>
    </div>



  </table>



</body>

</html>