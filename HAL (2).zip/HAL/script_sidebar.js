const body_here=document.querySelector("body")
const sidebar_here=body_here.querySelector(".sidebar")
fetch('sidebar.html')
.then(res=>res.text())
.then(data=>{
    
    sidebar_here.innerHTML=data
})